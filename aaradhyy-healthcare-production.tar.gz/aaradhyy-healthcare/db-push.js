/**
 * One-time database initialiser.
 *
 * Reads ./db/schema.sql and executes it against $DATABASE_URL.
 * Safe to run multiple times — every CREATE statement uses IF NOT EXISTS.
 *
 * Usage:
 *   1. Ensure DATABASE_URL is set in .env (or in the shell environment).
 *   2. Run:  npm run db:push
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

// Load .env if dotenv-style file is present (no dotenv dep — keep it small)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const envFile = path.join(__dirname, ".env");
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    const [, k, v] = m;
    if (!process.env[k]) {
      process.env[k] = v.replace(/^['"]|['"]$/g, "");
    }
  }
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error("❌ DATABASE_URL is not set. Edit .env first.");
  process.exit(1);
}

const sqlFile = path.join(__dirname, "db", "schema.sql");
if (!fs.existsSync(sqlFile)) {
  console.error("❌ db/schema.sql not found.");
  process.exit(1);
}

const raw = fs.readFileSync(sqlFile, "utf8");
// Drizzle's generated SQL uses --> statement-breakpoint markers
const statements = raw
  .split(/-->\s*statement-breakpoint/i)
  .map((s) => s.trim())
  .filter(Boolean);

const client = new pg.Client({ connectionString: url });
await client.connect();
console.log(`Connected. Running ${statements.length} statements...`);

let ok = 0,
  skipped = 0,
  failed = 0;
for (const stmt of statements) {
  try {
    await client.query(stmt);
    ok++;
  } catch (e) {
    const msg = String(e.message || e);
    if (
      /already exists|duplicate/i.test(msg) ||
      /relation .* already exists/i.test(msg)
    ) {
      skipped++;
    } else {
      failed++;
      console.error("⚠️  Statement failed:");
      console.error("    " + stmt.split("\n")[0]);
      console.error("    " + msg);
    }
  }
}

await client.end();
console.log(`\n✅ Done.  ok=${ok}  skipped=${skipped}  failed=${failed}`);
if (failed > 0) {
  process.exit(2);
}
