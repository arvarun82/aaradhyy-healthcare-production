CREATE TYPE "public"."user_role" AS ENUM('super_admin', 'clinic_admin', 'doctor', 'reception', 'billing', 'patient');--> statement-breakpoint
CREATE TYPE "public"."gender" AS ENUM('male', 'female', 'other');--> statement-breakpoint
CREATE TYPE "public"."visit_status" AS ENUM('registered', 'in_consultation', 'completed', 'discharged', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."visit_type" AS ENUM('opd', 'ipd', 'follow_up', 'tele');--> statement-breakpoint
CREATE TYPE "public"."payment_method" AS ENUM('razorpay', 'qr', 'bank');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('pending', 'awaiting_verification', 'paid', 'failed', 'rejected', 'refunded');--> statement-breakpoint
CREATE TYPE "public"."certificate_status" AS ENUM('draft', 'issued', 'revoked');--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"clerk_user_id" text NOT NULL,
	"email" text NOT NULL,
	"full_name" text NOT NULL,
	"role" "user_role" DEFAULT 'patient' NOT NULL,
	"phone" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_clerk_user_id_unique" UNIQUE("clerk_user_id")
);
--> statement-breakpoint
CREATE TABLE "patients" (
	"id" serial PRIMARY KEY NOT NULL,
	"patient_uid" text NOT NULL,
	"user_id" integer,
	"full_name" text NOT NULL,
	"dob" date,
	"gender" "gender" DEFAULT 'male' NOT NULL,
	"mobile" text NOT NULL,
	"email" text,
	"address" text,
	"city" text,
	"state" text DEFAULT 'Gujarat',
	"pincode" text,
	"blood_group" text,
	"emergency_contact_name" text,
	"emergency_contact_phone" text,
	"allergies" text,
	"chronic_conditions" text,
	"notes" text,
	"registered_by_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "patients_patient_uid_unique" UNIQUE("patient_uid")
);
--> statement-breakpoint
CREATE TABLE "visits" (
	"id" serial PRIMARY KEY NOT NULL,
	"visit_uid" text NOT NULL,
	"patient_id" integer NOT NULL,
	"visit_type" "visit_type" DEFAULT 'opd' NOT NULL,
	"visit_date" timestamp with time zone DEFAULT now() NOT NULL,
	"doctor_id" integer,
	"chief_complaint" text,
	"diagnosis" text,
	"status" "visit_status" DEFAULT 'registered' NOT NULL,
	"consultation_fee_paise" integer,
	"notes" text,
	"registered_by_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "visits_visit_uid_unique" UNIQUE("visit_uid")
);
--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"actor_email" text,
	"actor_role" text,
	"action" text NOT NULL,
	"entity_type" text,
	"entity_id" text,
	"details" jsonb,
	"ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "home_care_bookings" (
	"id" serial PRIMARY KEY NOT NULL,
	"booking_id" text NOT NULL,
	"patient_name" text NOT NULL,
	"mobile" text NOT NULL,
	"age" integer NOT NULL,
	"gender" "gender" DEFAULT 'male' NOT NULL,
	"address" text NOT NULL,
	"landmark" text,
	"service_slug" text NOT NULL,
	"service_name" text NOT NULL,
	"preferred_date" text NOT NULL,
	"preferred_time" text NOT NULL,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "home_care_bookings_booking_id_unique" UNIQUE("booking_id")
);
--> statement-breakpoint
CREATE TABLE "feedback" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text,
	"mobile" text,
	"rating" integer,
	"message" text NOT NULL,
	"source" text DEFAULT 'exit_popup',
	"page_url" text,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "quotation_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"quotation_id" text NOT NULL,
	"company_name" text NOT NULL,
	"contact_person" text NOT NULL,
	"designation" text,
	"mobile" text NOT NULL,
	"email" text,
	"industry_type" text NOT NULL,
	"worker_count" integer NOT NULL,
	"factory_location" text NOT NULL,
	"required_package" text,
	"required_services" text NOT NULL,
	"frequency" text,
	"message" text,
	"status" text DEFAULT 'new' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "quotation_requests_quotation_id_unique" UNIQUE("quotation_id")
);
--> statement-breakpoint
CREATE TABLE "medicines" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"strength" text,
	"form" text,
	"route" text,
	"default_frequency" text,
	"default_duration" text,
	"notes" text,
	"added_by_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "case_papers" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_paper_uid" text NOT NULL,
	"patient_id" integer NOT NULL,
	"visit_id" integer,
	"consultant_name" text,
	"chief_complaint" text,
	"history" text,
	"examination" text,
	"diagnosis" text,
	"advice" text,
	"follow_up_date" date,
	"issued_by_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "case_papers_case_paper_uid_unique" UNIQUE("case_paper_uid")
);
--> statement-breakpoint
CREATE TABLE "prescriptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"rx_uid" text NOT NULL,
	"patient_id" integer NOT NULL,
	"visit_id" integer,
	"doctor_id" integer,
	"diagnosis" text,
	"chief_complaint" text,
	"medicines" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"lab_tests" text,
	"advice" text,
	"rest_days" integer,
	"diet_advice" text,
	"follow_up_date" date,
	"notes" text,
	"vitals" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "prescriptions_rx_uid_unique" UNIQUE("rx_uid")
);
--> statement-breakpoint
CREATE TABLE "pay_services" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" text NOT NULL,
	"name" text NOT NULL,
	"category" text DEFAULT 'consultation' NOT NULL,
	"base_price_paise" integer NOT NULL,
	"allow_emergency" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"description" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "pay_services_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" serial PRIMARY KEY NOT NULL,
	"payment_ref_id" text NOT NULL,
	"invoice_number" text,
	"service_slug" text NOT NULL,
	"service_name" text NOT NULL,
	"base_paise" integer NOT NULL,
	"surcharge_paise" integer DEFAULT 0 NOT NULL,
	"surcharge_reason" text,
	"total_paise" integer NOT NULL,
	"payer_name" text NOT NULL,
	"payer_mobile" text NOT NULL,
	"payer_email" text,
	"booking_date" text,
	"booking_time" text,
	"notes" text,
	"method" "payment_method" NOT NULL,
	"status" "payment_status" DEFAULT 'pending' NOT NULL,
	"razorpay_order_id" text,
	"razorpay_payment_id" text,
	"razorpay_signature" text,
	"manual_utr" text,
	"manual_screenshot_url" text,
	"verified_by_id" integer,
	"verified_at" timestamp with time zone,
	"rejection_reason" text,
	"user_id" integer,
	"receipt_emailed_at" timestamp with time zone,
	"unlock_otp" text,
	"unlock_otp_expires_at" timestamp with time zone,
	"unlock_attempts" integer DEFAULT 0 NOT NULL,
	"unlocked" integer DEFAULT 0 NOT NULL,
	"unlocked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payments_payment_ref_id_unique" UNIQUE("payment_ref_id"),
	CONSTRAINT "payments_invoice_number_unique" UNIQUE("invoice_number")
);
--> statement-breakpoint
CREATE TABLE "radiology_referral_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"patient_name" text NOT NULL,
	"mobile" text NOT NULL,
	"city" text,
	"scan_needed" text NOT NULL,
	"preferred_centre" text,
	"preferred_date" text,
	"prescription_url" text,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "radiology_referral_requests_request_id_unique" UNIQUE("request_id")
);
--> statement-breakpoint
CREATE TABLE "laboratory_referral_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"patient_name" text NOT NULL,
	"mobile" text NOT NULL,
	"city" text,
	"address" text,
	"test_needed" text NOT NULL,
	"preferred_lab" text,
	"preferred_date" text,
	"preferred_time" text,
	"home_collection" text DEFAULT 'no' NOT NULL,
	"prescription_url" text,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "laboratory_referral_requests_request_id_unique" UNIQUE("request_id")
);
--> statement-breakpoint
CREATE TABLE "medicolegal_consultations" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"full_name" text NOT NULL,
	"mobile" text NOT NULL,
	"email" text,
	"city" text,
	"consultation_type" text NOT NULL,
	"case_summary" text NOT NULL,
	"document_url" text,
	"preferred_date" text,
	"preferred_time" text,
	"mode" text DEFAULT 'online' NOT NULL,
	"consent_given" boolean DEFAULT false NOT NULL,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "medicolegal_consultations_request_id_unique" UNIQUE("request_id")
);
--> statement-breakpoint
CREATE TABLE "vaccination_bookings" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"full_name" text NOT NULL,
	"age" text,
	"mobile" text NOT NULL,
	"email" text,
	"category" text NOT NULL,
	"country" text,
	"vaccine_needed" text NOT NULL,
	"existing_diseases" text,
	"preferred_date" text,
	"preferred_centre" text,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"source_ip" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "vaccination_bookings_request_id_unique" UNIQUE("request_id")
);
--> statement-breakpoint
CREATE TABLE "certificates" (
	"id" serial PRIMARY KEY NOT NULL,
	"certificate_number" text NOT NULL,
	"doc_id" text NOT NULL,
	"type" text NOT NULL,
	"status" "certificate_status" DEFAULT 'draft' NOT NULL,
	"patient_id" integer,
	"patient_snapshot" jsonb NOT NULL,
	"data" jsonb NOT NULL,
	"body_text" text,
	"created_by_id" integer,
	"issued_by_id" integer,
	"issued_at" timestamp with time zone,
	"revision_log" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "certificates_certificate_number_unique" UNIQUE("certificate_number"),
	CONSTRAINT "certificates_doc_id_unique" UNIQUE("doc_id")
);
--> statement-breakpoint
ALTER TABLE "patients" ADD CONSTRAINT "patients_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "patients" ADD CONSTRAINT "patients_registered_by_id_users_id_fk" FOREIGN KEY ("registered_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "visits" ADD CONSTRAINT "visits_patient_id_patients_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patients"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "visits" ADD CONSTRAINT "visits_doctor_id_users_id_fk" FOREIGN KEY ("doctor_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "visits" ADD CONSTRAINT "visits_registered_by_id_users_id_fk" FOREIGN KEY ("registered_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_added_by_id_users_id_fk" FOREIGN KEY ("added_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_papers" ADD CONSTRAINT "case_papers_patient_id_patients_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patients"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_papers" ADD CONSTRAINT "case_papers_visit_id_visits_id_fk" FOREIGN KEY ("visit_id") REFERENCES "public"."visits"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_papers" ADD CONSTRAINT "case_papers_issued_by_id_users_id_fk" FOREIGN KEY ("issued_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prescriptions" ADD CONSTRAINT "prescriptions_patient_id_patients_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patients"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prescriptions" ADD CONSTRAINT "prescriptions_visit_id_visits_id_fk" FOREIGN KEY ("visit_id") REFERENCES "public"."visits"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prescriptions" ADD CONSTRAINT "prescriptions_doctor_id_users_id_fk" FOREIGN KEY ("doctor_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_verified_by_id_users_id_fk" FOREIGN KEY ("verified_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "certificates" ADD CONSTRAINT "certificates_patient_id_patients_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."patients"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "certificates" ADD CONSTRAINT "certificates_created_by_id_users_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "certificates" ADD CONSTRAINT "certificates_issued_by_id_users_id_fk" FOREIGN KEY ("issued_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "users_clerk_idx" ON "users" USING btree ("clerk_user_id");--> statement-breakpoint
CREATE INDEX "users_email_idx" ON "users" USING btree ("email");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");--> statement-breakpoint
CREATE INDEX "patients_uid_idx" ON "patients" USING btree ("patient_uid");--> statement-breakpoint
CREATE INDEX "patients_mobile_idx" ON "patients" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "patients_name_idx" ON "patients" USING btree ("full_name");--> statement-breakpoint
CREATE INDEX "patients_user_id_idx" ON "patients" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "visits_patient_idx" ON "visits" USING btree ("patient_id");--> statement-breakpoint
CREATE INDEX "visits_uid_idx" ON "visits" USING btree ("visit_uid");--> statement-breakpoint
CREATE INDEX "visits_date_idx" ON "visits" USING btree ("visit_date");--> statement-breakpoint
CREATE INDEX "visits_status_idx" ON "visits" USING btree ("status");--> statement-breakpoint
CREATE INDEX "audit_user_idx" ON "audit_log" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "audit_action_idx" ON "audit_log" USING btree ("action");--> statement-breakpoint
CREATE INDEX "audit_created_idx" ON "audit_log" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "hcb_booking_id_idx" ON "home_care_bookings" USING btree ("booking_id");--> statement-breakpoint
CREATE INDEX "hcb_mobile_idx" ON "home_care_bookings" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "hcb_created_at_idx" ON "home_care_bookings" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "feedback_created_at_idx" ON "feedback" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "feedback_rating_idx" ON "feedback" USING btree ("rating");--> statement-breakpoint
CREATE INDEX "qr_quotation_id_idx" ON "quotation_requests" USING btree ("quotation_id");--> statement-breakpoint
CREATE INDEX "qr_mobile_idx" ON "quotation_requests" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "qr_created_at_idx" ON "quotation_requests" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "medicines_name_idx" ON "medicines" USING btree ("name");--> statement-breakpoint
CREATE INDEX "case_papers_patient_idx" ON "case_papers" USING btree ("patient_id");--> statement-breakpoint
CREATE INDEX "case_papers_uid_idx" ON "case_papers" USING btree ("case_paper_uid");--> statement-breakpoint
CREATE INDEX "case_papers_created_idx" ON "case_papers" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "prescriptions_patient_idx" ON "prescriptions" USING btree ("patient_id");--> statement-breakpoint
CREATE INDEX "prescriptions_uid_idx" ON "prescriptions" USING btree ("rx_uid");--> statement-breakpoint
CREATE INDEX "prescriptions_created_idx" ON "prescriptions" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "pay_services_slug_idx" ON "pay_services" USING btree ("slug");--> statement-breakpoint
CREATE INDEX "pay_services_category_idx" ON "pay_services" USING btree ("category");--> statement-breakpoint
CREATE INDEX "payments_ref_idx" ON "payments" USING btree ("payment_ref_id");--> statement-breakpoint
CREATE INDEX "payments_status_idx" ON "payments" USING btree ("status");--> statement-breakpoint
CREATE INDEX "payments_method_idx" ON "payments" USING btree ("method");--> statement-breakpoint
CREATE INDEX "payments_mobile_idx" ON "payments" USING btree ("payer_mobile");--> statement-breakpoint
CREATE INDEX "payments_created_idx" ON "payments" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "payments_razorpay_order_idx" ON "payments" USING btree ("razorpay_order_id");--> statement-breakpoint
CREATE INDEX "rrr_request_id_idx" ON "radiology_referral_requests" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "rrr_mobile_idx" ON "radiology_referral_requests" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "rrr_status_idx" ON "radiology_referral_requests" USING btree ("status");--> statement-breakpoint
CREATE INDEX "rrr_created_at_idx" ON "radiology_referral_requests" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "lrr_request_id_idx" ON "laboratory_referral_requests" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "lrr_mobile_idx" ON "laboratory_referral_requests" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "lrr_status_idx" ON "laboratory_referral_requests" USING btree ("status");--> statement-breakpoint
CREATE INDEX "lrr_created_at_idx" ON "laboratory_referral_requests" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "mlc_request_id_idx" ON "medicolegal_consultations" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "mlc_mobile_idx" ON "medicolegal_consultations" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "mlc_status_idx" ON "medicolegal_consultations" USING btree ("status");--> statement-breakpoint
CREATE INDEX "mlc_created_at_idx" ON "medicolegal_consultations" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "vac_request_id_idx" ON "vaccination_bookings" USING btree ("request_id");--> statement-breakpoint
CREATE INDEX "vac_mobile_idx" ON "vaccination_bookings" USING btree ("mobile");--> statement-breakpoint
CREATE INDEX "vac_status_idx" ON "vaccination_bookings" USING btree ("status");--> statement-breakpoint
CREATE INDEX "vac_created_at_idx" ON "vaccination_bookings" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "cert_number_idx" ON "certificates" USING btree ("certificate_number");--> statement-breakpoint
CREATE INDEX "cert_doc_id_idx" ON "certificates" USING btree ("doc_id");--> statement-breakpoint
CREATE INDEX "cert_type_idx" ON "certificates" USING btree ("type");--> statement-breakpoint
CREATE INDEX "cert_patient_idx" ON "certificates" USING btree ("patient_id");--> statement-breakpoint
CREATE INDEX "cert_status_idx" ON "certificates" USING btree ("status");--> statement-breakpoint
CREATE INDEX "cert_created_at_idx" ON "certificates" USING btree ("created_at");