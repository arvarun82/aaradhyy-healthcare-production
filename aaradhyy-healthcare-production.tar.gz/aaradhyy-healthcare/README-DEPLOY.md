# Aaradhyy Healthcare — Hostinger Deployment Guide

Production-ready, single-process Node.js app. The bundled server serves both:
- The React frontend (static files in `public/`)
- The REST API at `/api/*` (Clerk auth, Razorpay, SMTP, Postgres)

---

## 0. What you need before starting

| Requirement | Where to get it |
| --- | --- |
| Hostinger plan with **Node.js support** | Business / Cloud / VPS plan (shared hosting plans without Node.js will NOT work) |
| Postgres database URL | Hostinger VPS + install Postgres, OR free Supabase / Neon / Railway |
| Clerk account | https://clerk.com (free tier — copy publishable + secret keys) |
| Razorpay live keys | https://dashboard.razorpay.com → Settings → API Keys |
| SMTP mailbox | Hostinger email (`info@aaradhyyhealthcare.com`) — already configured |
| Domain pointed to Hostinger | DNS A-record / nameservers |

---

## 1. Provision Postgres

If using Supabase / Neon: create a project, copy the connection string. It will look like:
```
postgres://USER:PASS@HOST:5432/DBNAME
```

If using a Hostinger VPS:
```bash
sudo apt install postgresql -y
sudo -u postgres psql -c "CREATE USER aaradhyy WITH PASSWORD 'STRONGPASS';"
sudo -u postgres psql -c "CREATE DATABASE aaradhyy OWNER aaradhyy;"
```
Connection string: `postgres://aaradhyy:STRONGPASS@127.0.0.1:5432/aaradhyy`

---

## 2. Upload the package to Hostinger

1. Log into hPanel → **Files → File Manager** (or use FTP / SSH).
2. Upload the entire folder `aaradhyy-healthcare/` to your home directory.
   Recommended path: `/home/USERNAME/aaradhyy-healthcare/`
3. (Optional) Upload via SSH instead:
   ```bash
   scp -r aaradhyy-healthcare USER@your-server:/home/USER/
   ```

---

## 3. Configure environment variables

In the uploaded folder, copy `.env.example` to `.env`:

```bash
cd /home/USERNAME/aaradhyy-healthcare
cp .env.example .env
nano .env       # fill in every value
```

**Required values:**
- `DATABASE_URL`
- `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`
- `SUPER_ADMIN_EMAIL` (the email you will sign up with — it auto-promotes to super admin)
- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`
- `SMTP_*` (already provided in example for Hostinger)
- `PUBLIC_APP_URL` = your live domain, e.g. `https://aaradhyyhealthcare.com`

---

## 4. Install dependencies & initialise the database

In Hostinger → **Advanced → Node.js** → Create Application:
- Node.js version: **20** or higher
- Application root: `/home/USERNAME/aaradhyy-healthcare`
- Application URL: your domain
- Application startup file: `server.js`

Then click **Run NPM Install** in the Node.js panel. Or via SSH:

```bash
cd /home/USERNAME/aaradhyy-healthcare
npm install --omit=dev
npm run db:push        # creates all 17 tables in Postgres
```

You should see:
```
✅ Done.  ok=NN  skipped=0  failed=0
```

---

## 5. Register the Razorpay webhook

In Razorpay Dashboard → **Settings → Webhooks → Add New Webhook**:

| Field | Value |
| --- | --- |
| Webhook URL | `https://aaradhyyhealthcare.com/api/pay/razorpay/webhook` |
| Secret | (any strong random string — paste the same value into `RAZORPAY_WEBHOOK_SECRET` in `.env`) |
| Active Events | `payment.captured`, `payment.failed`, `order.paid` |

---

## 6. Start the server

In hPanel Node.js Selector → **Start App**.
Or via SSH:
```bash
npm start
```

Visit `https://aaradhyyhealthcare.com`. You should see the Aaradhyy Healthcare landing page.

---

## 7. Create the super-admin account

1. Open the site → click **Sign In** (top-right).
2. Sign up with the email you set in `SUPER_ADMIN_EMAIL`.
3. After verification, you are auto-promoted to **super_admin**.
4. Visit `/staff/users` to manage other users' roles.

---

## 8. Verify everything works

| What to test | Expected |
| --- | --- |
| Public homepage loads | ✅ |
| `/services` and other static pages | ✅ |
| Sign in / sign up | Clerk modal opens, you can register |
| `/dashboard` after login | Patient dashboard visible |
| `/staff` (as super-admin) | Staff dashboard visible |
| Book an appointment → Pay Online | Razorpay popup opens with all methods |
| Receipt email | Arrives within 1 minute |

---

## Folder structure of this package

```
aaradhyy-healthcare/
  server.js                   # bundled Express + API + static + SPA fallback
  pino-*.mjs                  # logging workers (auto-loaded by server.js)
  thread-stream-worker.mjs
  package.json                # production deps + scripts
  .env.example                # template — copy to .env
  db-push.js                  # one-time DB setup
  db/
    schema.sql                # 17 tables, indexes, foreign keys
  public/                     # built frontend (React + Vite)
    index.html
    assets/
    *.png *.svg *.jpg
  README-DEPLOY.md            # this file
```

---

## Updating the app later

When new code is built:
1. Replace `server.js`, `public/`, and `db/schema.sql` with the new versions.
2. Run `npm run db:push` again (idempotent — only adds new tables/columns).
3. Restart the Node.js app from hPanel.

---

## Troubleshooting

**"Missing Clerk publishable key"** — `CLERK_PUBLISHABLE_KEY` not in `.env` or app not restarted.

**"DATABASE_URL is not set"** — Edit `.env`, set `DATABASE_URL`, then `npm run db:push`.

**Razorpay webhook "Signature mismatch"** — The webhook secret in Razorpay dashboard must exactly match `RAZORPAY_WEBHOOK_SECRET` in `.env`.

**Emails not sending** — Check `SMTP_PASS` is correct (Hostinger mailbox password, not your hPanel password). Test from staff dashboard → Settings → SMTP test.

**"Frontend build missing"** — `public/index.html` was not uploaded. Re-upload the `public/` folder.

**Port already in use** — On Hostinger, do NOT set `PORT` manually; Passenger assigns it. Remove the `PORT=` line from `.env`.

---

## Support

For backend code questions, contact your developer. For Hostinger Node.js issues, see Hostinger's docs: https://support.hostinger.com/en/articles/4455931-how-to-deploy-a-node-js-application
